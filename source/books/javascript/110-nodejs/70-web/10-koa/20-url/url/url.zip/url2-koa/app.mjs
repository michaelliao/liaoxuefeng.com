import Koa from 'koa';
import { bodyParser } from '@koa/bodyparser';

import controller from './controller.mjs';

const app = new Koa();

// log url:
app.use(async (ctx, next) => {
    console.log(`Process ${ctx.request.method} ${ctx.request.url}...`);
    await next();
});

// 解析request.body:
app.use(bodyParser());

// 使用controller(), 注意controller模块导出的是async函数，要通过await调用:
app.use(await controller());

app.listen(3000);
console.log('app started at port 3000...');
