import nunjucks from 'nunjucks';

function createEnv(path, { autoescape = true, noCache = false, watch = false, throwOnUndefined = false }, filters = {}) {
    const loader = new nunjucks.FileSystemLoader(path, {
        noCache: noCache,
        watch: watch
    });
    const env = new nunjucks.Environment(loader, {
        autoescape: autoescape,
        throwOnUndefined: throwOnUndefined
    });
    for (let name in filters) {
        env.addFilter(name, filters[name]);
    }
    return env;
}

const env = createEnv('view', {
    noCache: true
}, {
    hex: function (n) {
        return '0x' + n.toString(16);
    }
});

let s = env.render('hello.html', {
    name: '<Nunjucks>',
    fruits: ['Apple', 'Pear', 'Banana'],
    count: 12000
});

console.log('>>> render hello.html >>>');
console.log(s);

console.log('>>> render extend.html >>>');
console.log(env.render('extend.html', { header: 'Hello', body: 'bla bla bla...' }));
