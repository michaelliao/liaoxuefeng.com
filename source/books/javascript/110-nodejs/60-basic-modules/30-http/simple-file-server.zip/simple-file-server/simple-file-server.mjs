// 导入http模块:
import http from 'node:http';
import path from 'node:path';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';

// 设定www根目录为当前目录:
const wwwRoot = path.resolve('.');
console.log(`set www root: ${wwwRoot}`);

// 根据扩展名确定MIME类型:
const mimeMap = {
    '.html': 'text/html',
    '.txt': 'text/plain',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.ico': 'image/x-icon'
};

const mimeDefault = 'application/octet-stream';

function guessMime(pathname) {
    let n = pathname.lastIndexOf('.');
    if (n >= 0) {
        let ext = pathname.substring(n);
        return mimeMap[ext] || mimeDefault;
    }
    return mimeDefault;
}

// 创建http file server，并传入回调函数:
const server = http.createServer((request, response) => {
    // 获得HTTP请求的method和url:
    console.log(request.method + ': ' + request.url);
    if (request.method !== 'GET') {
        response.writeHead(400, { 'Content-Type': 'text/html' });
        response.end('<h1>400 Bad Request</h1>');
    } else {
        // 解析path: 
        let url = new URL(`http://localhost${request.url}`);
        let pathname = url.pathname;
        let filepath = path.join(wwwRoot, pathname);
        // TODO: 必要的安全检查
        // 检查文件状态:
        stat(filepath).then(st => {
            if (st.isFile()) {
                console.log('200 OK');
                // 发送200响应:
                response.writeHead(200, { 'Content-Type': guessMime(pathname) });
                // 将文件流导向response:
                createReadStream(filepath).pipe(response);
            } else {
                console.log('404 Not Found');
                response.writeHead(404, { 'Content-Type': 'text/html' });
                response.end('<h1>404 Not Found</h1>');
            }
        }).catch(err => {
            console.log('404 Not Found');
            response.writeHead(404, { 'Content-Type': 'text/html' });
            response.end('<h1>404 Not Found</h1>');
        });
    }
});

// 出错时返回400:
server.on('clientError', (err, socket) => {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
});

// 让服务器监听8080端口:
server.listen(8080);
console.log('Server is running at http://127.0.0.1:8080/');
