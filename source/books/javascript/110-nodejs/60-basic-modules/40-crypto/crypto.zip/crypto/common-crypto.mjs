import crypto from 'node:crypto';

//////////////////// Hash ////////////////////

function hash(alg, msg) {
    const h = crypto.createHash(alg);
    // 可任意多次调用update():
    h.update(msg);
    return h.digest('hex');
}

console.log('MD5: ' + hash('md5', 'Hello, world!')); // 6cd3556deb0da54bca060b4c39479839
console.log('SHA1: ' + hash('sha1', 'Hello, world!')); // 943a702d06f34599aee1f8da8ef9f7296031d699

//////////////////// Hmac ////////////////////

function hmac(alg, key, msg) {
    const h = crypto.createHmac(alg, key);
    h.update(msg);
    return h.digest('hex');
}

// 相同的msg，不同的key会计算出不同hmac:
console.log('HmacSHA1: ' + hmac('sha1', 'a1b2c3d4', 'Hello, world!')); // 6e40a1c930fad4ec3d3f9d431e1553983421e372
console.log('HmacSHA1: ' + hmac('sha1', 'A1B2C3D4', 'Hello, world!')); // af75fe8f20dd88c3b6f86f17c9abfbbe5f978e13

//////////////////// AES ////////////////////

function aes_encrypt(key, iv, msg) {
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    // input encoding: utf8
    // output encoding: hex
    let encrypted = cipher.update(msg, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

function aes_decrypt(key, iv, encrypted) {
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

// AES-256-CBC算法要求的key必须为32bytes:
let key = 'Passw0rdPassw0rdPassw0rdPassw0rd';
// iv的长度必须为16bytes:
let iv = 'a1b2c3d4e5f6g7h8';
let msg = 'Hello, world!';
// 加密:
let encrypted_msg = aes_encrypt(key, iv, msg);
// 解密:
let decrypted_msg = aes_decrypt(key, iv, encrypted_msg);

console.log(`AES encrypt: ${encrypted_msg}`);
console.log(`AES decrypt: ${decrypted_msg}`);

//////////////////// DiffieHellman ////////////////////

// xiaoming's keys:
let ming = crypto.createDiffieHellman(512);
let ming_keys = ming.generateKeys();

let prime = ming.getPrime();
let generator = ming.getGenerator();

console.log('Prime: ' + prime.toString('hex'));
console.log('Generator: ' + generator.toString('hex'));

// xiaohong's keys:
let hong = crypto.createDiffieHellman(prime, generator);
let hong_keys = hong.generateKeys();

// exchange and generate secret:
let ming_secret = ming.computeSecret(hong_keys);
let hong_secret = hong.computeSecret(ming_keys);

// 检查双方用DH算法生成的secret是否一样:
console.log('Secret of Xiao Ming: ' + ming_secret.toString('hex'));
console.log('Secret of Xiao Hong: ' + hong_secret.toString('hex'));
console.log('Same?', ming_secret.toString('hex') === hong_secret.toString('hex'));

//////////////////// RSA ////////////////////

import fs from 'node:fs';

// 从文件加载key:
function loadKey(file) {
    // key实际上就是PEM编码的字符串:
    return fs.readFileSync(file, 'utf8');
}

let
    prvKey = loadKey('./rsa-prv.pem'),
    pubKey = loadKey('./rsa-pub.pem'),
    message = 'Hello, world!';

// 使用私钥加密:
let enc_by_prv = crypto.privateEncrypt(prvKey, Buffer.from(message, 'utf8'));
console.log('RSA Encrypt: ' + enc_by_prv.toString('hex'));

let dec_by_pub = crypto.publicDecrypt(pubKey, enc_by_prv);
console.log('RSA Decrypt: ' + dec_by_pub.toString('utf8'));
