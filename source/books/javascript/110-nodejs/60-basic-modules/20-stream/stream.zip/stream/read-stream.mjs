import { createReadStream } from 'node:fs';

let rs = createReadStream('sample.txt', 'utf-8');

rs.on('data', (chunk) => {
    console.log('---- chunk ----');
    console.log(chunk);
});

rs.on('end', () => {
    console.log('---- end ----');
});

rs.on('error', err => {
    console.log(err);
});
