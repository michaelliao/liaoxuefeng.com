import { createWriteStream } from 'node:fs';

let ws = createWriteStream('output.txt', 'utf-8');
ws.write('使用Stream写入文本数据...\n');
ws.write('继续写入...\n');
ws.write('DONE.\n');
ws.end(); // 结束写入

// 写入二进制数据:
let b64array = ['iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAMAAABHPGVmAAADAFBMVEUAAAD///+HwEOHwEKFwUFyvCp0vi6DwkVvtyFyuSZxtyhzuCl2uS15vDF2ujB4uTF7',
    'vDWEwkGDwUKEwkODv0KFwkWFwkeHwkePxlSSxVyWyV+WyGGZyWWm0neq1nur1X2o0Xus1IGt1IVqsxJttBlytiBzuSJ0uyRztiN1uCVytiV3uid1uSd1tyZ1',
    'tyh3uSl0tih1tSh3vCt2uSp6uyx5uSx4ui18vS57vC57uy56uS55ui97uzB3ty99vTF/vzJ7ujJ9vDN7vDN8uzN7uTJ+vTV7ujR+uzWAvTeBvjh+vDiDwDqB',
    'vTmEwjyCvjuHwz+DwT6Cvj2AvT2Fwj+FwT+GwT+GwUCEvj+HwkGFv0CEvUCGwUKHwUKIwkOGwUOFv0KHwkSIwkSFvUKGwUSIwUSHwESIwkaJwUaKwkeHwUeG',
    'vkeKwkmHwEiHv0iMxkyNwk6KwE2SxVWWyVqTx1mUx1mUx1qZyWKdzWWXxGGdy2mizm6p0nnI4apmrQlxtB11tiF2uiN3tyN1tyR1tSR2uSV5uSd3uSd3tid2',
    'tCd5uyl2tih6vCp5uip4uCl4uCp6uit7uSt5tip9uy16uC1/vjB8ui9+vDB9uS96ty9+ujB8ujB+uTB7uTB9uTB/vDN+uzN8uDJ9tzKBvzWBvjZ+uDSCvzeA',
    'vDaBujaEwTqCvjmCvTmCvTqGwjyHwT2EvzyCuzuFwD2Gvj2Fvj6Gvj6EvD2Fuz6KwkGJwkGHwUGIwEGGvkCHv0GHv0KJv0KIwEOKwESKwkWNxEeJv0WHukSK',
    'wEeNw0mLv0iMwUqUyVCRxE6RxVKRwlKUxlWVxViWxlqayl+Ww1+cymOgzWeeymahzWqdx2qhym6kzHCmznOs03upznit0X+11oturxZ5tiR8uCuAuyx9ty1/',
    'uy9/uS+CvTKBujKDvjSCvDSDvDeFvjmKwj2MwUKKwEKNwUWLv0SJtkuUxVKXx1eZxliSu1mdx2Gkzmqiymqt0Xu72ZKKvjuNv0CZxlSXw1Wmy2+z0oP///8i',
    '++KoAAABAHRSTlP/////////////////////////////////////////////////////////////////////////////////////////////////////////',
    '////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////',
    '//////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AU/cH',
    'JQAAAAlwSFlzAAALEwAACxMBAJqcGAAACgFJREFUaIHtWntYVNUW/50584DxnZhZoDA8hGQCNQy1EA0QwSKRRt7JzPCh3ozkK/1Sutr9UMtKzZvmk8FABOOV',
    '2chDQTBFTSPlHU+5Ib5SEUdgYObcPySd5+GcqPvH/Vp/7VmP/Ttrnb32XmufISj89cT5H2D8DfI3yN8gDIjL1qC6u8diiiU7G4LdttI9wSafr04dN0PMxopV',
    'uCbNH0vWVFdUt9rmKkR/EUi0gAzxUQYEBGgzG4dxY5kbMg/XT6HvnTsIGeV3QDg2mUBMy+3kaQxNyQ3M9Op6BB3XO+usanpViZWiFcMrpo2W2+UKrRgZM1td',
    'VEh+xghV2gleVZT/FOyrlvaCs29BvVXumepmBuaMwtX36aUzPhk40XxzxchHnIqIZ+06Cangk1ub/P4UENUBnuhbtSK2/epezyfcs3LbNa+Ckv6sSncfMkiP',
    'J+UiAI8MqSytaNMV2L1Ut16pQIyqJmGWw5BAeoNL/awkKSSVaz//E0OhTWLfZQUQ01U7MUtAOw1FR/dcfKOiI0j5fOcEk/L7zoo4DhnB8Xe+SDcNXTKua0nx',
    'mKDVWAYesqv93KTGiNry0tSYDML65VPidX/Ek/q2jwqWRnCXntiU9gvNU9Z5ikk5Scq54nY71p6sPCTwQh8ZOe3tzghHmoecXJ7uNCOsSLFkVkXHMjM6ZkC6',
    'WmpuVGkXWN60n177MQ0EALjWTLl4XU7ut7zm5tZvWsWUe2uHf64uIcm4JUmHRHQv9DE1BjsFlpFkdPTGmXUmxCaWcGN8a5IyuZDjN43rvXEQLx5T5QiOfWQ/',
    'uN1TxSubDIXGINIzk0T7QUnr7qVMZwoBAJdk8af5GnCvtXt+aSgz8GyNy8zQfJKU+zv/g1GgdOnO1tfL5SQ3Yq/LGtpwHdziwbuPkapqW3ESGzceUdMI22Fv',
    'pCyRfSU+dt68J/HNv5XF5h93+3clazce0ep5MwqKi8lT4nhdrj6Ixa2TxXGjLUzvIczomef33CqOOvVPsyAVnxWT8vnjhwBBURR1q/UUWez2rA5HLxn3iHxQ',
    't+k6+5ehR1a3W+BrLdHh6IF0KglwLIaIARwBwFXrMLiG0rjUzYNP0+MQIlFTSOdKg6IyWw2lfbkAn9RhGO1dWuMp19mLGruf/Kx/w3ObXcPmvb5U8o01H5Y+',
    '7XOxUV+fjDKYgEm1Ql4Tia0bBn78svKHOR+lJQYC8COOogxFu9e2O2fTTsCkghzWNkV4Y2DcHcjP/0B4WBWsXEwQwQAl9aHG1KkcfxkqSObbst+HdR3NE7xT',
    'kdfp2tjz4os3/Hfu6wgRZEcVTQ4w2hV1iFFxl8O7P1AMveZR5CdNFtm6h/1nBYAaUu1QXBorSZvA//qjJ/qGmy4TEAqgwgAAP8qaqO93W+xqAxwB4HkAXu+e',
    'uEcpSmSL3M1OwKyqz4AGAJDgGj5/X9NlvfoL279sisXcF0+ZN2fYOuTzAABd3/rgbrK9gdB7vbcUgh7zFRzT/oQPAI1CSgZKaCR0rtUiNad6qCD+GgDo40OL',
    '2INGUvus+l9Tl9zV4/WwBgklvgYAl7lHgZEm6rxs5y0OnuP0WAd0xuy631xtH/LmHfYwLLCd9xmpynTG7Pr4WU5vQSHK+O61C1WDNaZcM2MaGsiTbe2jgP34',
    '/njb5nEpo54KJU8STn8ayO95IhjvXkj4AgsAZUDuVneJMmf4+NGC2EH6E4ae5A/s5sPefLdVEusLIACLgCJQhKReKxWKP6WzZpUnADZdkd75aZ6/BBSUSgAE',
    'jhSePDvSTnyexpihJ/47Hg+3o9arZ6NXUN6ee99kyv0BAsjJjsgvSjRrzTRP0nR+uXi8kn/VZ8fZqV5hW6Z6eQUWAUT6tTy1WXPWt0QD1AR0AEFBTar+3e97',
    'P3uIOHBy4wZiiCCkGb49sFfkaS/cj1dfWugxRJBoAKjSErYjjGXNqMoCYNVjLHpEDM8TigJwT161ZonJ5HPlhADfm2mzmJ8nXADcVXmF70c2mpJPVwHwNWfN',
    'NFxqAMM3V8JnWqepbrtFehwhJiL5iJieJyQAxIUAomMmxL21b1KL5wzTZenGjtV54nZVGSIVpRjL7zhQ4G/T67D3sAYZoOm3KWBSuofBQWu3ZdFE5fEH7c66',
    'zD9ynnABQHAgfkzA/mfGFykuVItsAABrGzRLx51xugNt1UVjAxNjOgoHAMwpCJBTnSuzH6Sc4/se3sUVjFUWJgZrIpFGndvl8lhZYTAxmzwBYJtUdn9ZYPLw',
    'tUHd3Dx7e+v+rorF/YuQG7QqQGcBhx8J1jNnkycAEJzbvswLSCaQg7SUFIAghqFxwt6jM3TVM2V62xjrDdL59MQXyMlkgS8/WJIZofK2SKl8avp3hboqRHpB',
    'Fmc5HQgn1NTU/l89GbcBDb1t4WnW2tHHl5L4wnIyPPWU33QvhF689C4LwrnpmL3bBQY0tWpJpudpGu8M6MqZEqif26nz4LrSUVEUyG5DG9bU941M1s/XYeiB',
    'LK+Swum9I6b6GRbv7ugV2wCBX4wuS6/PdyghybiF6+P1u3/LxVzuTqZXBasckss4klC9Gwn9Jfxg+QnsT2hPFqp0mL12RGbwfWZedO+waTmTGi249Lr5MHTs',
    'Wx4m9UWU6vPzlY87ncq1VsmULRMIkaPPjwKK85bWb57eVZlBrGNb8mZFkwpYUBalcx6x6i9VLMrKGsUAo7AjKT+HikNrQ7z+vaXxzd25OOUVDgJlif13RzgC',
    'mi/O88j0j6/TlogA0PmylU1EYAl3/dWDngYi41XjeaEzYVOB9ICW19z11kNIajWaWM7uqkEgHt4JbrhpTdy6WB41y7DdM7U0BU9fCuyyK/KRFcFay3Hv5SHz',
    '4jb6u3j7pAbxlrS+pRrbmZ+a+KRmcv0LSxJGrSYoAtmAADzZjxMX0mLwHDWN/0KYRb1amG9KbvarQ/zZReVCZFPh+K3J+iQdREXYmA1AYMyvs29vN61B82nj',
    '567b2725k/leW+nuPBNtt4tGqald59a5OJjTG+T7yYeJ9C+j92hzzHu9mj2cr/C6q1ktll9MDahMbr+GUoPq2BxEu8SZ7kl2q4xY1s4bo4rJsrMLHI/T2zKt',
    'VjrHnWzTv9TrmTumsSXdN7y3/K7En96YUbguKa5okr6+12Sz40mevTPGtVCBInXT6rMvDGbPyBO3gkrXvoel0yMPTxjgJLjUtIxUUPLrK90fDIrB9J2Ur+/4',
    'IZIkS2bzLlMUVekznIzMl0QFOi1sZGLNdHVRNw5etlBnlHR+MHvszQsbjmh5lp0v8WXGN0amiOmLJ555x62OQ80Vzm63mj8zR5PD9xR/tpIZBqs8iSs7VesT',
    'CmSAirjeGrCdsSGbqn7PsfJJOTwAMVmXbY4xx2Cb8ZWndz9n/euswlc2sbFiva2sU706fqTz4HpDAvkj9P/zD5z/AqLMjuSii7cXAAAAAElFTkSuQmCC'
];

let ws2 = createWriteStream('output.png');
for (let b64 of b64array) {
    let buf = Buffer.from(b64, 'base64');
    ws2.write(buf); // 写入Buffer对象
}
ws2.end(); // 结束写入
