import { writeFile } from 'node:fs';

console.log('BEGIN');

let data = 'Hello, Node.js';
writeFile('output.txt', data, function (err) {
    if (err) {
        console.log(err);
    }
});

console.log('END');
