import { readFile } from 'node:fs';

console.log('BEGIN');

readFile('sample.png', function (err, data) {
    if (err) {
        console.log(err);
    } else {
        console.log(data instanceof Buffer); // true
        console.log(data); // Buffer(12451) [137, 80, 78, 71, 13, ...]
    }
});

console.log('END');
