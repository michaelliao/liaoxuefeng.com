'use strict';

const greet = require('./hello');

let name = 'Bob';
greet(name);
