package com.itranswarp.learnjava;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.HexFormat;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Main {

    static final String AES_ALG      = "AES/GCM/NoPadding";
    static final int    AES_KEY_SIZE = 256;
    static final int    AES_TAG_SIZE = 128;
    static final int    AES_IV_SIZE  = 96;

    static SecureRandom srnd = new SecureRandom();

    public static void main(String[] args) throws Exception {
        // 明文:
        byte[] plain = "Hello，使用AES-GCM对称加密算法对数据进行加密！".getBytes("UTF-8");
        // 创建256bit密钥:
        byte[] key = "ABCDEFGHIJ_0123456789_abcdefghij".getBytes(StandardCharsets.UTF_8);
        if (key.length != 32) {
            throw new IllegalArgumentException("Invalid key length.");
        }

        // 加密:
        byte[] encryptedData = encrypt(key, plain);
        System.out.println("Key: " + HexFormat.of().formatHex(key));
        System.out.println("Enc: " + HexFormat.of().formatHex(encryptedData));

        // 解密:
        byte[] decryptedData = decrypt(key, encryptedData);
        System.out.println(new String(decryptedData, "UTF-8"));
    }

    static byte[] encrypt(byte[] key, byte[] msg) throws Exception {
        byte[] iv = generateIv();
        SecretKey skey = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance(AES_ALG);
        GCMParameterSpec spec = new GCMParameterSpec(AES_TAG_SIZE, iv);
        cipher.init(Cipher.ENCRYPT_MODE, skey, spec);
        byte[] enc = cipher.doFinal(msg);
        return ByteBuffer.allocate(iv.length + enc.length).put(iv).put(enc).array();
    }

    static byte[] decrypt(byte[] key, byte[] encData) throws Exception {
        byte[] iv = new byte[AES_IV_SIZE / 8];
        byte[] enc = new byte[encData.length - AES_IV_SIZE / 8];
        ByteBuffer.wrap(encData).get(iv).get(enc);
        SecretKey skey = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance(AES_ALG);
        GCMParameterSpec spec = new GCMParameterSpec(AES_TAG_SIZE, iv);
        cipher.init(Cipher.DECRYPT_MODE, skey, spec);
        return cipher.doFinal(enc);
    }

    // 生成随机IV:
    static byte[] generateIv() {
        return secureRandom(AES_IV_SIZE / 8);
    }

    static byte[] secureRandom(int len) {
        byte[] buffer = new byte[len];
        srnd.nextBytes(buffer);
        return buffer;
    }
}
