module hello.world {
	requires java.base;
	requires java.xml;
}
