
/**
 * 定义抽象类Income
 */
public abstract class Income {

	// TODO

}
