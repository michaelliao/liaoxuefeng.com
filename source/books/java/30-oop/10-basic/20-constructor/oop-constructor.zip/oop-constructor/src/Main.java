
/**
 * Learn Java from https://www.liaoxuefeng.com/
 * 
 * @author liaoxuefeng
 */
public class Main {

	public static void main(String[] args) {
		// FIXME: 给Person增加构造方法:
		Person ming = new Person("小明", 12);
		System.out.println(ming.getName());
		System.out.println(ming.getAge());
	}

}
