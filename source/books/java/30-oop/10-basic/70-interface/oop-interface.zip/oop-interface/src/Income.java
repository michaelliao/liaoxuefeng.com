
/**
 * 定义接口Income
 */
public interface Income {

	// TODO

}
