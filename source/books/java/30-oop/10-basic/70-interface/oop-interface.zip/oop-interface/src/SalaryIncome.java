
public class SalaryIncome {

	// TODO

}
