package com.itranswarp.learnjava.command;

public interface Command {

	void execute();
}
