package com.itranswarp.learnjava.observer;

public interface ProductObservable {

	

}
