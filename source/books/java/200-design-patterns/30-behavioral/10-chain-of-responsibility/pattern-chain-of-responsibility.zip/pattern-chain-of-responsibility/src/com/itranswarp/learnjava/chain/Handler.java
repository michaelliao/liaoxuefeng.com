package com.itranswarp.learnjava.chain;

public interface Handler {

	Boolean process(Request request);
}
