package com.itranswarp.learnjava.node;

public interface TextNode {

	void setText(String text);

	String getText();
}
