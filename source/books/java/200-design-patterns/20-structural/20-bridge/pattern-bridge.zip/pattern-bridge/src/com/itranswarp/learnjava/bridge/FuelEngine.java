package com.itranswarp.learnjava.bridge;

public class FuelEngine implements Engine {

	@Override
	public void start() {
		System.out.println("Start Fuel Engine...");
	}
}
