package com.itranswarp.learnjava.bean;

public class School {

	public String name;
	public String address;

	public School(String name, String address) {
		this.name = name;
		this.address = address;
	}
}
